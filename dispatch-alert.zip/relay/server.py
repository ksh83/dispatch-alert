# relay/server.py
# ---------------------------------------------------------
# 외부(클라우드) 릴레이 API
# - /health, /subscribe, /unsubscribe, /toggle-hold, /list, /event
# - 구독: 메모리 + 일일 JSON(당일) 유지, 매일 09:00 리셋
# - 문자발송: Solapi SDK(있으면) / 없으면 REST(테스트용)
# - 인증: Authorization: Bearer <RELAY_AUTH_TOKEN>
# ---------------------------------------------------------

from __future__ import annotations
import os, re, json, hashlib
from typing import Dict, Any, List, Optional
from datetime import datetime
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from dotenv import load_dotenv
import requests

try:
    from solapi import Message, Solapi  # pip install solapi
    HAS_SOLAPI_SDK = True
except Exception:
    HAS_SOLAPI_SDK = False

load_dotenv(override=True)

APP_TZ = os.getenv("APP_TZ", "Asia/Seoul").strip() or "Asia/Seoul"
TZ = ZoneInfo(APP_TZ)

DATA_DIR = os.path.abspath(os.getenv("DATA_DIR", "./data"))
ARCHIVE_DIR = os.path.abspath(os.getenv("ARCHIVE_DIR", "./archive"))
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(ARCHIVE_DIR, exist_ok=True)

RELAY_AUTH_TOKEN = os.getenv("RELAY_AUTH_TOKEN", "").strip()
if not RELAY_AUTH_TOKEN:
    print("[WARN] RELAY_AUTH_TOKEN is empty (development mode).")

# Solapi
SOLAPI_API_KEY = os.getenv("SOLAPI_API_KEY", "").strip()
SOLAPI_API_SECRET = os.getenv("SOLAPI_API_SECRET", "").strip()
SOLAPI_SENDER = os.getenv("SOLAPI_SENDER", "").strip()

VEHICLES = [
    "금암구급1","금암구급2",
    "금암펌프1","금암펌프2",
    "금암물탱크","굴절","사다리","구조","대응단"
]
VEHICLE_SET = set(VEHICLES)

def now_tz() -> datetime:
    return datetime.now(TZ)

def today_str_compact() -> str:
    return now_tz().strftime("%Y%m%d")

def now_iso() -> str:
    return now_tz().isoformat(timespec="seconds")

def mask_phone(p: str) -> str:
    d = re.sub(r"\D", "", p or "")
    if len(d) == 11:
        return f"{d[:3]}-{d[3:7]}-{d[7:]}"
    if len(d) == 10:
        return f"{d[:3]}-{d[3:6]}-{d[6:]}"
    return p or ""

def line_hash(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8", errors="ignore")).hexdigest()

# ---------- Storage ----------
class Storage:
    def __init__(self):
        self.today = today_str_compact()
        self.json_path = os.path.join(DATA_DIR, f"subscribers_{self.today}.json")
        self.state: Dict[str, Dict[str, Any]] = {}  # phone -> record
        self._dedup: Dict[str, bool] = {}  # line_hash -> sent
        self._load()

    def _load(self):
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, "r", encoding="utf-8") as f:
                    obj = json.load(f)
                    self.state = obj.get("state", {})
                    self._dedup = obj.get("dedup", {})
            except Exception:
                self.state, self._dedup = {}, {}
        else:
            self._persist()

    def _persist(self):
        with open(self.json_path, "w", encoding="utf-8") as f:
            json.dump({"state": self.state, "dedup": self._dedup}, f, ensure_ascii=False, indent=2)

    def ensure_today(self):
        t = today_str_compact()
        if t != self.today:
            self.rotate_to(t)

    def rotate_to(self, new_day: str):
        if os.path.exists(self.json_path):
            os.replace(self.json_path, os.path.join(ARCHIVE_DIR, os.path.basename(self.json_path)))
        self.today = new_day
        self.json_path = os.path.join(DATA_DIR, f"subscribers_{self.today}.json")
        self.state, self._dedup = {}, {}
        self._persist()

    def reset_0900(self):
        self.rotate_to(today_str_compact())

    def upsert(self, phone: str, vehicles: List[str], hold: bool = False):
        self.state[phone] = {
            "phone": phone,
            "vehicles": vehicles,
            "cancel_hold_until_09": hold,
            "created_at": now_iso(),
        }
        self._persist()

    def remove(self, phone: str):
        if phone in self.state:
            del self.state[phone]
            self._persist()

    def toggle_hold(self, phone: str):
        if phone in self.state:
            cur = bool(self.state[phone].get("cancel_hold_until_09", False))
            self.state[phone]["cancel_hold_until_09"] = not cur
            self._persist()
            return not cur
        raise KeyError("not subscribed")

    def list(self) -> List[Dict[str, Any]]:
        return list(self.state.values())

    def targets(self, vehicle: str) -> List[str]:
        out = []
        for rec in self.state.values():
            if vehicle in rec.get("vehicles", []):
                if not rec.get("cancel_hold_until_09", False):
                    out.append(rec["phone"])
        return out

    def seen(self, h: str) -> bool:
        return self._dedup.get(h, False)

    def mark_seen(self, h: str):
        self._dedup[h] = True
        # 간단히 사이즈 관리
        if len(self._dedup) > 2000:
            # 앞부분 일부 삭제
            for k in list(self._dedup.keys())[:1000]:
                del self._dedup[k]
        self._persist()

storage = Storage()

# ---------- SMS ----------
class SmsProvider:
    def __init__(self):
        self.last_result = None
        self.last_error = None
        self.client = None
        if all([SOLAPI_API_KEY, SOLAPI_API_SECRET, SOLAPI_SENDER]) and HAS_SOLAPI_SDK:
            try:
                self.client = Solapi(api_key=SOLAPI_API_KEY, api_secret=SOLAPI_API_SECRET)
            except Exception as e:
                print("[SOLAPI INIT ERROR]", e)

    def send(self, phone: str, text: str) -> bool:
        self.last_result, self.last_error = None, None
        if not all([SOLAPI_API_KEY, SOLAPI_API_SECRET, SOLAPI_SENDER]):
            print(f"[DEV-SMS] to={phone} text={text}")
            self.last_result = {"dev": True}
            return True
        # SDK 우선
        if self.client:
            try:
                msg = Message(to=re.sub(r"\D", "", phone), _from=SOLAPI_SENDER, text=text)
                res = self.client.message.send(msg)
                self.last_result = res
                return True
            except Exception as e:
                self.last_error = str(e)
                print("[SOLAPI ERROR]", e)
                return False
        # SDK 없으면 간단 REST (권장X)
        try:
            url = "https://api.solapi.com/messages/v4/send"
            payload = {"message": {"to": re.sub(r"\D","",phone), "from": SOLAPI_SENDER, "text": text}}
            headers = {"Content-Type": "application/json; charset=utf-8"}
            r = requests.post(url, json=payload, headers=headers, timeout=10)
            self.last_result = {"status": r.status_code, "body": r.text[:200]}
            return 200 <= r.status_code < 300
        except Exception as e:
            self.last_error = str(e)
            print("[SOLAPI RAW ERROR]", e)
            return False

sms = SmsProvider()

# ---------- Auth ----------
def check_auth(authorization: Optional[str]):
    if not RELAY_AUTH_TOKEN:
        return
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Unauthorized")
    token = authorization.split(" ", 1)[1].strip()
    if token != RELAY_AUTH_TOKEN:
        raise HTTPException(status_code=403, detail="Forbidden")

# ---------- Schemas ----------
class SubscribeReq(BaseModel):
    phone: str = Field(..., description="숫자만 10~11자리")
    vehicles: List[str]

class UnsubscribeReq(BaseModel):
    phone: str

class ToggleReq(BaseModel):
    phone: str

class EventReq(BaseModel):
    vehicle: str
    raw_line: str
    ts: Optional[str] = None  # ISO string, optional

# ---------- App ----------
app = FastAPI(title="Dispatch Relay API", version="1.0")

@app.on_event("startup")
def on_start():
    # Scheduler
    app.scheduler = BackgroundScheduler(timezone=TZ)
    app.scheduler.add_job(lambda: storage.reset_0900(),
                          CronTrigger(hour=9, minute=0, timezone=TZ),
                          name="daily_reset_09")
    app.scheduler.start()
    print(f"[START] Relay up. TZ={APP_TZ}")

@app.get("/health")
def health():
    return {"ok": True, "now": now_iso(), "tz": APP_TZ}

@app.post("/subscribe")
def subscribe(req: SubscribeReq, authorization: Optional[str] = Header(None)):
    check_auth(authorization)
    for v in req.vehicles:
        if v not in VEHICLE_SET:
            raise HTTPException(400, f"unknown vehicle: {v}")
    storage.upsert(req.phone, req.vehicles, hold=False)
    return {"ok": True}

@app.post("/unsubscribe")
def unsubscribe(req: UnsubscribeReq, authorization: Optional[str] = Header(None)):
    check_auth(authorization)
    storage.remove(req.phone)
    return {"ok": True}

@app.post("/toggle-hold")
def toggle_hold(req: ToggleReq, authorization: Optional[str] = Header(None)):
    check_auth(authorization)
    try:
        newv = storage.toggle_hold(req.phone)
        return {"ok": True, "cancel_hold_until_09": newv}
    except KeyError:
        raise HTTPException(404, "not subscribed")

@app.get("/list")
def list_subs(authorization: Optional[str] = Header(None)):
    check_auth(authorization)
    return [{"phone": mask_phone(r["phone"]),
             "vehicles": r.get("vehicles", []),
             "hold": bool(r.get("cancel_hold_until_09", False)),
             "created_at": r.get("created_at","")} for r in storage.list()]

@app.post("/event")
def event(req: EventReq, authorization: Optional[str] = Header(None)):
    check_auth(authorization)
    vehicle = req.vehicle.replace(" ", "")
    if vehicle not in VEHICLE_SET:
        return JSONResponse({"ok": False, "reason": "vehicle_not_allowed"}, status_code=200)

    # 중복 방지
    h = line_hash(req.raw_line)
    if storage.seen(h):
        return {"ok": True, "skipped": "duplicate"}
    storage.mark_seen(h)

    targets = storage.targets(vehicle)
    if not targets:
        return {"ok": True, "skipped": "no_subscribers"}

    text = f"[출동알림] {vehicle}"
    ok, fail = 0, 0
    for p in targets:
        sent = sms.send(p, text)
        ok += 1 if sent else 0
        fail += 0 if sent else 1

    return {"ok": True, "vehicle": vehicle, "sent_ok": ok, "sent_fail": fail,
            "last_result": sms.last_result, "last_error": sms.last_error}
