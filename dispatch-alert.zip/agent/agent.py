# agent/agent.py
# ---------------------------------------------------------
# 지령PC(내부망)에서 실행
# - 로그 파일 append를 감시(watchdog)
# - 마지막 [ ]의 차량명을 추출
# - 릴레이 API /event 로 POST
# ---------------------------------------------------------
 
import os, re, time, threading, requests
from typing import Optional
from datetime import datetime
from zoneinfo import ZoneInfo
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from dotenv import load_dotenv
from collections import deque
import hashlib

load_dotenv(override=True)

APP_TZ = os.getenv("APP_TZ", "Asia/Seoul").strip() or "Asia/Seoul"
TZ = ZoneInfo(APP_TZ)

LOG_DIR = os.path.abspath(os.getenv("LOG_DIR", "./logs"))
LOG_PREFIX = os.getenv("LOG_FILE_PREFIX", "ERSS_").strip()

RELAY_BASE_URL = os.getenv("RELAY_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
RELAY_AUTH_TOKEN = os.getenv("RELAY_AUTH_TOKEN", "").strip()  # relay와 동일

VEHICLES = [
    "금암구급1","금암구급2",
    "금암펌프1","금암펌프2",
    "금암물탱크","굴절","사다리","구조","대응단"
]
VEHICLE_SET = set(VEHICLES)

os.makedirs(LOG_DIR, exist_ok=True)

def now_tz():
    return datetime.now(TZ)

def today_str_dots():
    return now_tz().strftime("%Y.%m.%d")

def current_log_path():
    return os.path.join(LOG_DIR, f"{LOG_PREFIX}{today_str_dots()}.txt")

def last_bracket_value(line: str) -> Optional[str]:
    m = re.findall(r"\[([^\[\]]+)\]", line)
    if not m:
        return None
    return m[-1].strip().replace(" ", "")

def line_hash(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8", errors="ignore")).hexdigest()

def post_event(vehicle: str, raw_line: str):
    url = f"{RELAY_BASE_URL}/event"
    headers = {"Authorization": f"Bearer {RELAY_AUTH_TOKEN}"} if RELAY_AUTH_TOKEN else {}
    payload = {"vehicle": vehicle, "raw_line": raw_line, "ts": now_tz().isoformat(timespec="seconds")}
    try:
        r = requests.post(url, json=payload, headers=headers, timeout=8)
        print("[POST /event]", r.status_code, r.text[:200])
    except Exception as e:
        print("[POST ERROR]", e)

class TailHandler(FileSystemEventHandler):
    def __init__(self, agent):
        super().__init__()
        self.agent = agent

    def on_modified(self, event):
        if not event.is_directory and os.path.abspath(event.src_path) == os.path.abspath(self.agent.current_file):
            self.agent.tail_new_lines()

class Agent:
    def __init__(self):
        self.current_file = current_log_path()
        self._tail_pos = 0
        self._mutex = threading.Lock()
        self._dedup = deque(maxlen=200)
        self._dedup_set = set()
        self.observer = None

    def run(self):
        print("[AGENT] Start watch:", self.current_file)
        self._prepare_tail()
        handler = TailHandler(self)
        self.observer = Observer()
        self.observer.schedule(handler, path=LOG_DIR, recursive=False)
        self.observer.start()
        try:
            while True:
                # 날짜 변경 체크 (30초마다)
                time.sleep(30)
                newf = current_log_path()
                if newf != self.current_file:
                    print("[AGENT] Rollover ->", newf)
                    self.current_file = newf
                    self.restart_watch()
        except KeyboardInterrupt:
            pass
        finally:
            self.observer.stop()
            self.observer.join()

    def restart_watch(self):
        try:
            if self.observer:
                self.observer.stop()
                self.observer.join(timeout=2)
        except Exception:
            pass
        self.run()

    def _prepare_tail(self):
        path = self.current_file
        if not os.path.exists(path):
            open(path, "a", encoding="utf-8").close()
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            f.seek(0, os.SEEK_END)
            self._tail_pos = f.tell()

    def tail_new_lines(self):
        path = self.current_file
        with self._mutex:
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    f.seek(self._tail_pos)
                    lines = f.readlines()
                    self._tail_pos = f.tell()
                for raw in lines:
                    line = raw.rstrip("\n")
                    if not line.strip():
                        continue
                    self._handle_line(line)
            except Exception as e:
                print("[TAIL ERROR]", e)

    def _handle_line(self, line: str):
        h = line_hash(line)
        if h in self._dedup_set:
            return
        self._dedup.append(h)
        self._dedup_set.add(h)
        if len(self._dedup) == self._dedup.maxlen:
            self._dedup_set.discard(self._dedup[0])

        vehicle = last_bracket_value(line)
        if not vehicle or vehicle not in VEHICLE_SET:
            return
        post_event(vehicle, line)

if __name__ == "__main__":
    Agent().run()
